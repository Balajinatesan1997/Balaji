<?php 
include "config.php";

// if the form's update button is clicked, we need to process the form
	if (isset($_POST['update'])) {
		$moment = $_POST['moment'];
		$user_id = $_POST['user_id'];
		$time = $_POST['time'];
		$fromlocation = $_POST['fromlocation'];
		$tolocation = $_POST['tolocation'];
		$quantity = $_POST['quantity'];

		// write the update query
		$sql = "UPDATE `users` SET `moment`='$moment',`time`='$time',`fromlocation`='$fromlocation',`tolocation`='$tolocation',`quantity`='$quantity' WHERE `id`='$user_id'";

		// execute the query
		$result = $conn->query($sql);

		if ($result == TRUE) {
			echo "Record updated successfully.";
		}else{
			echo "Error:" . $sql . "<br>" . $conn->error;
		}
	}


// if the 'id' variable is set in the URL, we know that we need to edit a record
if (isset($_GET['id'])) {
	$user_id = $_GET['id'];

	// write SQL to get user data
	$sql = "SELECT * FROM `users` WHERE `id`='$user_id'";

	//Execute the sql
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		
		while ($row = $result->fetch_assoc()) {
			$moment = $row['moment'];
			$time = $row['time'];
			$fromlocation = $row['fromlocation'];
			$tolocation  = $row['tolocation'];
			$quantity = $row['quantity'];
			$id = $row['id'];
		}

	?>
		<h2>User Update Form</h2>
		<form action="" method="post">
		  <fieldset>
		    <legend>Personal information:</legend>
		    Moment:<br>
		    <input type="text" name="moment" value="<?php echo $moment; ?>">
		    <input type="hidden" name="user_id" value="<?php echo $id; ?>">
		    <br>
		    Time:<br>
		    <input type="text" name="time" value="<?php echo $time; ?>">
		    <br>
		    From Location:<br>
		    <input type="text" name="fromlocation" value="<?php echo $fromlocation; ?>">
		    <br>
		     To Location:<br>
		    <input type="text" name="tolocation" value="<?php echo $tolocation; ?>">
		    <br>
		    Quantity:<br>
		    <input type="text" name="quantity" value="<?php echo $quantity; ?>">
		    <br>
		    <br><br>
		    <input type="submit" value="Update" name="update">
		  </fieldset>
		</form>

		</body>
		</html>




	<?php
	} else{
		// If the 'id' value is not valid, redirect the user back to view.php page
		header('Location: view.php');
	}

}
?>