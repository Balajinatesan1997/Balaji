<?php 
include "config.php";

// if the form's submit button is clicked, we need to process the form
	if (isset($_POST['submit'])) {
		// get variables from the form
		$moment = $_POST['moment'];
		$time = $_POST['time'];
		$fromlocation = $_POST['fromlocation'];
		$tolocation = $_POST['tolocation'];
		$quantity = $_POST['quantity'];

		//write sql query

		$sql = "INSERT INTO `users`(`moment, `time', `fromlocation`, `tolocation`, `quantity`) VALUES ('$moment,'$time,'$fromlocation','$tolocation','$quantity')";

		// execute the query

		$result = $conn->query($sql);

		if ($result == TRUE) {
			echo "New record created successfully.";
		}else{
			echo "Error:". $sql . "<br>". $conn->error;
		}

		$conn->close();

	}



?>

<!DOCTYPE html>
<html>
<body>

<h2>Signup Form</h2>

<form action="" method="POST">
  <fieldset>
    <legend>Personal information:</legend>
    Moment:<br>
    <input type="text" name="moment">
    <br>
    Time:<br>
    <input type="text" name="time">
    <br>
    From Location:<br>
    <input type="text" name="fromlocation">
    <br>
     To location:<br>
    <input type="text" name="tolocation">
    <br>
    Quantity:<br>
    <input type="text" name="quantity">
    <br>
    <input type="submit" name="submit" value="submit">
  </fieldset>
</form>

</body>
</html>