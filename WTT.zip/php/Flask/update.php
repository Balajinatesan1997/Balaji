<?php 
include "config.php";


	if (isset($_POST['update'])) {
		$location = $_POST['location'];
		$user_id = $_POST['user_id'];

		
		$sql = "UPDATE `users` SET `location`='$location' WHERE `id`='$user_id'";

	
		$result = $conn->query($sql);

		if ($result == TRUE) {
			echo "Record updated successfully.";
		}else{
			echo "Error:" . $sql . "<br>" . $conn->error;
		}
	}



if (isset($_GET['id'])) {
	$user_id = $_GET['id'];


	$sql = "SELECT * FROM `users` WHERE `id`='$user_id'";


	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		
		while ($row = $result->fetch_assoc()) {
			$location = $row['location'];
			$id = $row['id'];
		}

	?>
		<h2>User Update Form</h2>
		<form action="" method="post">
		  <fieldset>
		    <legend>Personal information:</legend>
		    First name:<br>
		    <input type="text" name="location" value="<?php echo $location; ?>">
		    <input type="hidden" name="user_id" value="<?php echo $id; ?>">
		    <br>
		    <input type="submit" value="Update" name="update">
		  </fieldset>
		</form>

		</body>
		</html>




	<?php
	} else{
	
		header('Location: view.php');
	}

}
?>